Difficult things: Setting up the initial connection to MongoDB Atlas/learning the functionality
		  Exporting the data to CSV
Easy things:	  Reading data, resetting data, exporting to JSON

Im not sure what the exact funcionality was meant to be with "building" and "reading" from the database. I 
made separate buttons for each, where the build button just appends a new collection to the db, and the read
reads the most recent collection and outputs the data that was appended.
		  