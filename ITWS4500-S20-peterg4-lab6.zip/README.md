Features:	login/user system
          	save photos to profile
		search photos by keyword
		explore trending photos
		explore trending collections of photos
		infinite scroll on all pages	

Difficult things: infinite scroll, setting up the login system w/ mongo
Easy things:	  styling output and branding

		  